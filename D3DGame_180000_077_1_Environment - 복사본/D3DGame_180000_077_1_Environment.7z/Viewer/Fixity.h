#pragma once
#include "Camera.h"

class Fixity : public Camera
{
public:
	Fixity();
	~Fixity();

	void Update();

private:
	
};